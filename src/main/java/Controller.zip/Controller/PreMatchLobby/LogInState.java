package Controller.PreMatchLobby;

import Controller.Controller;
import Controller.Exceptions.*;
import Controller.RealTimeBuilding.BuildingState;
import Controller.State;
import Model.Player;


/**
 * Initial game state that manages player login/logout.
 * Coordinates player entry into the match and game startup.
 *
 */
public class LogInState extends State {

    /**
     * Constructor for the login state.
     *
     * @param controller The game controller
     */
    public LogInState(Controller controller) {
        super(controller);
    }

    /**
     * Handles a player's login to the match.
     * Verifies the name isn't already in use and there's space.
     *
     * @param name Name of the player wanting to join
     * @throws InvalidParameters If the name is already in use or match is full
     * @throws InvalidCommand If there's an error in the command
     */
    @Override
    public void login(String name) throws InvalidParameters, InvalidCommand{

        Player test= this.getController().getModel().getPlayer(name);
        if(test != null){
            throw new InvalidParameters("Player with this name already connected");
        }
        if(this.getController().getModel().getPlayers().size() == 4){
            throw new InvalidParameters("Game is full");
        }

        this.getController().getModel().addPlayer(name);

        // Handle the login action here
        System.out.println("Player " + name + " logged in to game " + this.getController().getGameID());
        // You can add more logic here if needed
    }

    /**
     * Handles a player's logout from the match.
     * If it was the last player, shuts down the match.
     *
     * @param name Name of the player wanting to leave
     * @throws InvalidParameters If the player doesn't exist
     */
    @Override
    public void logout(String name)throws InvalidParameters {

        Player removed_player= this.getController().getModel().getPlayer(name);
        if(removed_player == null){
            throw new InvalidParameters("Player with this name not connected");
        }
        this.getController().getModel().removePlayer(name);
        if(this.getController().getModel().getPlayers().isEmpty()){

            //qui andrebbe eliminata dalla lista partite accedibili
            this.getController().setState(new OffState(this.getController()));
            //TODO: offstate è uno stato inutile, semplicemnete segnala una partita non inziata
            // senza più giocatori dipende da come vogliamo gestire il caso

        }
        System.out.println("Player " + name + " logged out");
        // You can add more logic here if needed
    }

    /**
     * Starts the match if requested by the administrator.
     * Only the first player (admin) can start the match.
     *
     * @param name Name of the player requesting startup
     * @throws InvalidParameters If the player is not the admin
     * @throws InvalidCommand If there aren't enough players
     */
    @Override
    public void startGame(String name) throws InvalidParameters, InvalidCommand {
        Player admin= this.getController().getModel().getPlayers().get(0);
        if(!admin.getName().equals(name)){
            throw new InvalidParameters("Only the admin can start the game");
        }

        if(this.getController().getModel().getPlayers().size() < 2){
            throw new InvalidCommand("Not enough players to start the game");
        }

        this.getController().setState(new BuildingState(this.getController()));

        System.out.println("Game started by admin " + name);
        // You can add more logic here if needed
    }
}
